package com.example.library;

import android.app.Activity;

import com.example.library.annotation.EventBase;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * Created by 梁明伟 on 2019/4/24.
 * Copyright © 2018年 CETC. All rights reserved.
 */
public class InjectManager {


    public static void inject(Activity activity) {
         //事件注入
        injectEvent(activity);
    }

    private static void injectEvent(Activity activity) {
        //获取到class
        Class<?> clazz = activity.getClass();
        //获取类中的所有方法
        Method[] methods = clazz.getDeclaredMethods();

        //遍历方法获取方法上的注解
        for (Method method : methods) {
            
            Annotation[] annotations = method.getAnnotations();
            //遍历每个方法的多个注解
            for (Annotation annotation : annotations) {
                Class<?extends Annotation> annotationType = annotation.annotationType();
                if(annotationType !=null) {
                    //这里不太明白
                    EventBase eventBase = annotationType.getAnnotation(EventBase.class);

                    String setlistener = eventBase.setOnClickListener();
                    Class<?> listenerType = eventBase.OnClickListener();
                    String listenercallback = eventBase.listenercallback();

                    try {
                        Method valueMethod = annotationType.getDeclaredMethod("value");
                        int[] viewids = (int[]) valueMethod.invoke(annotation);

                        ListenerInvacationHandler handler = new ListenerInvacationHandler(activity);
                        handler.addMethodHashMap(listenercallback,method);

                        //打包之后代理处理后续工作
                        Object listener = Proxy.newProxyInstance(listenerType.getClassLoader(),new Class[]{listenerType},handler);

                        for (int viewid : viewids) {
                            Method getView = clazz.getMethod("findViewById", int.class);
                            Object view = getView.invoke(activity,viewid);
                            Method setter = view.getClass().getMethod(setlistener,listenerType);
                            setter.invoke(view,listener);

                        }


                    } catch (Exception e) {
                        e.printStackTrace();
                    }


                }

            }

        }

    }


}
