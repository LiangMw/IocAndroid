package com.example.library;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.HashMap;

/**
 * Created by 梁明伟 on 2019/4/24.
 * Copyright © 2018年 CETC. All rights reserved.
 */
public class ListenerInvacationHandler implements InvocationHandler {

    private Object target;
    private HashMap<String,Method> methodHashMap = new HashMap<>();

    public ListenerInvacationHandler(Object target) {
        this.target = target;
    }

    public void addMethodHashMap(String methodname, Method method) {
        methodHashMap.put(methodname,method);
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if(target != null) {
            String methodname = method.getName();
            method = methodHashMap.get(methodname);
            if(method != null) {
                if(method.getGenericParameterTypes().length == 0) {
                    return method.invoke(target);
                }else{
                    return method.invoke(target,args);
                }

            }

        }

        return null;
    }
}
