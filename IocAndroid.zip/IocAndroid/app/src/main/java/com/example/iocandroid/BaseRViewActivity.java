package com.example.iocandroid;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;

import com.example.recyclyviewlibrary.RViewHelper;
import com.example.recyclyviewlibrary.SwipeRefreshHelper;
import com.example.recyclyviewlibrary.listener.RViewCreate;

import java.util.List;

/**
 * Created by 梁明伟 on 2019/4/24.
 * Copyright © 2018年 CETC. All rights reserved.
 */
public abstract class BaseRViewActivity extends AppCompatActivity implements RViewCreate, SwipeRefreshHelper.SwipRefreshListener {


    private RViewHelper helper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        helper = new RViewHelper.Builder(this,this).build();
    }

    @Override
    public SwipeRefreshLayout createSwipRefresh() {
        return null;
    }

    @Override
    public int[] colorRes() {
        return new int[0];
    }

    @Override
    public RecyclerView createRecyclerView() {
        return null;
    }

    @Override
    public RecyclerView.LayoutManager createLayoutManager() {
        return null;
    }

    @Override
    public RecyclerView.ItemDecoration createItemDecoration() {
        return null;
    }

    @Override
    public int startPageNumber() {
        return 0;
    }

    @Override
    public boolean isSupportPaging() {
        return false;
    }

    protected void notifyAdapterDataSetChanged(List datas){
        helper.notifyAdapterDataSetChanged(datas);
    }

}
