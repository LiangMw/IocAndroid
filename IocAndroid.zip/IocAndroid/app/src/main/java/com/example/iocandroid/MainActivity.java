package com.example.iocandroid;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.library.InjectManager;
import com.example.library.annotation.onClick;

public class MainActivity extends BaseRViewActivity {

    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        InjectManager.inject(this);
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
////                Toast.makeText(MainActivity.this,btn.getText().toString(),Toast.LENGTH_SHORT).show();
//            }
//        });
    }

    @onClick(R.id.btn)
    public void show(View view){
        Toast.makeText(MainActivity.this,"ahhahahaha",Toast.LENGTH_SHORT).show();
    }
}
